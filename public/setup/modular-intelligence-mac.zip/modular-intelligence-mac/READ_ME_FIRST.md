# Welcome — let's get you ready 👋

This folder is the start of your own knowledge system. There's nothing to figure out yet — we'll set the real thing up **together** when we sit down.

All I need from you beforehand is **three free downloads**. They take about 15 minutes, and doing them first means our time together goes straight to the good stuff instead of watching progress bars.

---

## Before we meet — three free installs

Just download and install each one. You don't need to open them or understand them — we'll do that part together.

### 1. Python
- Most Macs already have this, so there may be nothing to do here.
- If I let you know yours needs it, go to **python.org/downloads**, click the big yellow **Download** button, open the file, and click through the installer (the standard options are fine).

### 2. Claude Code
- This is the AI that runs your system. Install it from the official instructions (link in my email).
- You don't need to sign in or set anything up — we'll handle your access together.

### 3. PyCharm
- This is the window you'll see your knowledge system in.
- Go to the PyCharm download page (link in my email) and get the free **Community Edition**.

---

## That's everything

Once those are installed, you're done — **don't open them or touch anything else.** When we sit down I'll drop your files into place, switch on the part that saves everything, get your access working, and we'll run your very first session right then.

You don't need to understand any of the files in this folder yet. That understanding comes naturally, at your pace, as you use it.

Stuck on anything at all? Just reply to my email or give me a call — genuinely happy to help.

Looking forward to it.
— Joel, Collaborative Research

---

*The other files in this folder (`CLAUDE.md`, `setup_guide.md`, the `.claude` folder) are for our session together — you can leave them exactly as they are.*
