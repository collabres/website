# Welcome — your Modular Intelligence setup (Windows)

This folder has the files for your knowledge system. **Before we sit down together**, please do the "Before we meet" steps so our time goes to the good stuff, not installing.

## Before we meet — install three free tools
1. **Python** — `python --version` — install from python.org and **tick "Add python.exe to PATH"** (the make-or-break step)
2. **Claude Code** — install per the current official instructions (it runs in a terminal).
3. **PyCharm** — the free **Community Edition**.

*(Full step-by-step in `setup_guide.md`.)*

## What's in this folder
- `CLAUDE.md` — the brain of your setup (we'll fill in your details together).
- `.claude/hooks/append_raw.py` — captures every session so nothing is ever lost.
- `.claude/settings.json` — switches the capture on (already set up for your computer).
- `setup_guide.md` — the full walkthrough.

## We'll do the rest together
When we sit down, we'll drop these into place, switch on the capture, get your access sorted, and start your first session. You don't need to understand the files yet — that comes naturally as you use it.

Looking forward to it.
— Joel
