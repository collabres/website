# Modular Intelligence — Client Setup Guide

> Gets a client (or Joel testing) from a blank machine to a working **Modular Intelligence** setup: PyCharm + Claude Code + the incremental capture hook + the CLAUDE template. **One shared core, a thin per-OS shim** — almost everything is identical on Mac and Windows; only **two things differ** (the Python install step, and one word in the hook command). Those points are marked **🍎 Mac** / **🪟 Windows** below.
>
> **Architecture (locked 2026-06-18):** *one* Induction template + capture hook (shared, OS-agnostic) + a *per-OS setup shim* (this guide's branches). Never two full templates — that just causes drift.

---

## What's shared vs per-OS

| | Shared (one copy, both OSes) | Per-OS |
|---|---|---|
| **The methodology** | `CLAUDE_template_(entity).md`, the process, the folder structure | — |
| **The capture hook** | `append_raw.py` (this folder — ports cleanly) | — |
| **Install steps** | Claude Code, PyCharm (same tools) | **Python install** (🍎/🪟 differ) |
| **Hook registration** | the `settings.json` shape + `${CLAUDE_PROJECT_DIR}` path | `command`: `python3` 🍎 vs `python` 🪟 |

That's the whole per-OS surface: the Python install, and `python3`-vs-`python` in one line.

---

## Prerequisites — what to install (do this *before* the sit-down where possible)

**1. Python** (the capture hook is a Python script)
- **🍎 Mac:** usually already has `python3`. Check in Terminal: `python3 --version`. If missing, install from [python.org](https://www.python.org/downloads/) or `brew install python`.
- **🪟 Windows:** download from [python.org](https://www.python.org/downloads/) and **tick "Add python.exe to PATH"** on the first installer screen (critical — without it the hook won't run). Check in a new terminal: `python --version`. *(If `python` isn't found, the `py` launcher usually works: `py --version`.)*

**2. Claude Code** — install per the current official instructions (it runs in the terminal — including PyCharm's built-in terminal). Sign in / configure the API access (CR-provided key for the Induction, or the client's own).

**3. PyCharm** — the free **Community Edition** is fine. Same app on both OSes (different installer).

---

## Setup steps (same on both OSes except where marked)

**1. Create the working folder** — e.g. `Documents/[name]-intelligence/`. This is *their* knowledge base; it lives on their machine.

**2. Drop in the two files:**
- `CLAUDE.md` ← copy from `CLAUDE_template_(entity).md` (rename to `CLAUDE.md`). Fill in the Client Profile.
- `.claude/hooks/append_raw.py` ← copy from this folder. **Open it and set `USER_LABEL`** (near the top) to the client's first name.

**3. Register the capture hook** — create `.claude/settings.json` in the working folder with:

**🍎 Mac:**
```json
{
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3",
            "args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/append_raw.py"],
            "timeout": 15
          }
        ]
      }
    ]
  }
}
```

**🪟 Windows:** identical, but `"command": "python"` (drop the `3`):
```json
{
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python",
            "args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/append_raw.py"],
            "timeout": 15
          }
        ]
      }
    ]
  }
}
```
*(`${CLAUDE_PROJECT_DIR}` works on both — Claude Code converts the slashes on Windows. Exec form with `args` avoids Windows quoting problems. If `python` isn't found on Windows, use `"command": "py"` with the same args.)*

**4. Open the folder in PyCharm** (File → Open → the working folder). For a non-technical client, strip the UI to **file tree + terminal** (hide debugger/run-config/VCS panels). They watch the tree fill up; they type into the terminal.

**5. Configure the API key** in Claude Code (CR's Induction key, or their own account).

---

## Verify the capture hook fires (the fail-safe — do this every install)

1. In PyCharm's terminal, in the working folder, start Claude Code.
2. Type one test message and let Claude respond.
3. Check that **`00_raw_capture/raw_(YYYY-MM).md`** now exists in the folder and contains the exchange, labelled `[USER_LABEL]-P1` / `Claude-R1`.
4. Send a second message → confirm a second exchange appends.

If that file appears and grows, **the incremental capture fail-safe is working** — nothing will be lost to a mid-session compaction. If it doesn't:
- 🪟 Windows: Python almost certainly isn't on PATH (re-run the installer with "Add to PATH"), or try `"command": "py"`.
- 🍎 Mac: confirm `python3 --version` works in that terminal.
- Both: confirm the path in `settings.json` matches `.claude/hooks/append_raw.py`.

---

## Notes

- **The hook is the fail-safe; the CLAUDE template's session-close "raw" step is belt-and-braces.** Once the hook is confirmed firing, the template's Claude-writes-raw step is redundant — resolving that overlap cleanly is a dry-run finding (see `dryrun_(school_leader)/induction_dryrun_notes.md`).
- **`scrub_verify.sh` is NOT part of this setup** — it's CR's own privacy tripwire (bash, Mac-only). Clients don't need it.
- **Python on PATH is the one real friction point for a non-technical Windows client** — the "Add to PATH" tick is the make-or-break. Smooth it in the pre-install guide (a screenshot of that checkbox is worth a lot).
