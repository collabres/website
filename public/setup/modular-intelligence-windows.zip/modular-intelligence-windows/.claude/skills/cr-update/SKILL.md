---
name: cr-update
description: Check for and apply CR Engine updates — fetches the version manifest from collabres.ai, explains what changed in plain language, applies with consent, verifies with the self-test, and logs the result. Use when the user asks to update, check for updates, or asks whether their system is current.
---

# /cr-update — the CR Engine updater

You are updating this install of the CR Engine. Follow these steps exactly. The
governing rules: **pull never push, consent before apply, engine files only, verify
after, log everything.**

## 1. Read the local state

Read `.claude/engine_config.json`. Note `engine_version`, `status` (`active` or
`as-is`), `platform` (`mac`/`windows`), and `user_label`. If the file is missing,
this is a pre-1.0 install — say so and stop; a pre-1.0 install is brought current
manually with CR (Joel), not by this skill.

## 2. Fetch the release state

Fetch `https://collabres.ai/engine/manifest.json` (WebFetch, or `curl -s` if
WebFetch is unavailable). If unreachable, report that the update server couldn't be
reached and stop — never improvise an update from another source.

Compare `manifest.engine_version` with the local `engine_version`:
- **Same** → tell the user they're current ("Engine 1.0.0 — up to date") and stop.
- **Newer** → fetch `https://collabres.ai/engine/CHANGELOG.md` and continue.

## 3. Propose — plain language, then wait

From the changelog, summarise what's new since the local version in one or two
sentences a non-technical reader understands. Separate the lanes:
- **Substrate (capture) fixes** — these apply to every install, regardless of status.
- **Intelligence improvements** — these apply **only if `status` is `active`**. If
  the install is `as-is`, say the improvements exist but are part of the active CR
  relationship, without pressure, and offer the substrate fixes alone.

Then ask: *"Want me to apply this now?"* Do not proceed without a yes.

## 4. Apply — engine files only

1. Download the platform bundle: `https://collabres.ai/engine/cr-engine-<version>-<platform>.zip`
   into a temp folder and unzip it.
2. For each file in the manifest's `files` list (respecting `platform` and skipping
   `intelligence`-layer files when the install is `as-is`):
   - Back up the current file to `.claude/update_backup/<version>/<path>` first.
   - Copy the new file into place at its `path`.
3. **Never** write to any path not listed in the manifest. The record —
   `00_raw_capture/`, context files, `hook_state.json`, `engine_config.json` — is
   untouchable. If the manifest appears to list a record path, refuse and report.

## 5. Verify

Run the self-test: `python3 .claude/selftest/capture_selftest.py` (or `python` on
Windows). If it FAILS: restore every file from the backup taken in step 4, re-run
the self-test to confirm the rollback, and report honestly what happened.

## 6. Stamp and log

On success:
- Update `engine_version` (and per-layer versions if present) in
  `.claude/engine_config.json`. Touch nothing else in that file.
- Append to `.claude/update_log.md`:

```
## <version> — applied <YYYY-MM-DD HH:MM>
- From: <old version>  To: <new version>
- Layers applied: substrate [+ intelligence]
- Files changed: <list>
- Self-test: PASS
```

Close by telling the user, in one sentence, what their system can do now that it
couldn't before.
