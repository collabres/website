#!/usr/bin/env python3
"""
CR Engine — raw conversation appender (substrate).

Client capture hook. Cross-platform (macOS/Windows). The user's label comes from
.claude/engine_config.json ("user_label") — this file itself is identical on every
install and never edited by hand. Registered on BOTH Stop and PostToolUse via
.claude/settings.json.

THE SPEC (see 21_engine/engine_spec.md): verbatim capture of every real user prompt
and every assistant-written response, in order, labelled, into monthly files at
00_raw_capture/raw_(YYYY-MM).md. Any behaviour short of that is a defect.

Fires after each tool call (PostToolUse) and each completed response (Stop). Always
appends to the monthly catch-all regardless of session state.

State is tracked in .claude/hook_state.json:
  last_written_assistant_uuid — the last assistant entry already written. New writes
                                 resume after it, so text emitted late in a turn —
                                 across multiple firings during long tool work
                                 (web fetches, subagents) — is never dropped.
  prompt_map        — {user_prompt_uuid: exchange_number} for the current month, so
                      text that arrives for an already-logged prompt in a later firing
                      is appended as a continuation instead of being skipped.
  last_month        — detects month rollover so exchange count/labels reset cleanly
  exchange_count    — sequential label counter for the current month's file

The transcript read waits (max ~1.8s) for the tail to end in assistant text before
proceeding — the turn's final message can hit disk milliseconds AFTER the Stop hook
starts reading (the R217 race, 2026-07-09), and a session's last exchange has no
later firing to heal it via continuation.

PostToolUse registration (2026-07-10): the harness prunes between-tool-call
assistant text from the transcript at turn end — only the turn's opening preamble
and final message persist — so a Stop-only hook is structurally blind to mid-turn
prose. PostToolUse firings capture that text during the turn, before the prune; the
lockfile guard below keeps overlapping firings (parallel tool calls) from
double-appending.
"""

import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

# Fallback only — the real label lives in .claude/engine_config.json ("user_label").
DEFAULT_USER_LABEL = "User"


def local_stamp(entry):
    """Local-time stamp for a transcript entry ('YYYY-MM-DD HH:MM:SS'), or '' if
    the entry carries no parseable timestamp. Transcript times are ISO-8601 UTC
    ('...Z'); the record speaks the user's local time. Ported from CR's own hook
    2026-08-17 — every install captures what CR's install captures."""
    ts = entry.get('timestamp')
    if not ts:
        return ''
    try:
        dt = datetime.fromisoformat(ts.replace('Z', '+00:00')).astimezone()
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return ''


def get_user_label(project_root):
    """The user's display label, from engine_config.json (never from this file)."""
    try:
        with open(project_root / '.claude' / 'engine_config.json') as f:
            label = json.load(f).get('user_label', '')
            if label and isinstance(label, str):
                return label.strip()
    except Exception:
        pass
    return DEFAULT_USER_LABEL


def extract_text(content):
    """Extract plain text from a message content field (string or list of blocks)."""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get('type') == 'text':
                text = block.get('text', '').strip()
                if text:
                    parts.append(text)
        return '\n\n'.join(parts)
    return ''


def is_real_user_prompt(entry):
    """Return True if this transcript entry is an actual user prompt."""
    if entry.get('type') != 'user':
        return False
    if entry.get('isSidechain', False):
        return False
    # Skill/command launches inject their instruction payload as a user-typed
    # turn (isMeta: true, sourceToolUseID set). The payload is plain text, so
    # the '<'-prefix check below never catches it and it displaces the user's
    # real prompt. The user's actual words arrive as a separate, unflagged
    # user entry.
    if entry.get('isMeta') or entry.get('sourceToolUseID'):
        return False
    msg = entry.get('message', {})
    content = msg.get('content', '')
    if isinstance(content, list):
        if any(isinstance(b, dict) and b.get('type') == 'tool_result' for b in content):
            return False
        text = extract_text(content)
        if text.startswith('<') or not text:
            return False
        return True
    if isinstance(content, str):
        text = content.strip()
        if not text or text.startswith('<'):
            return False
        return True
    return False


def collect_assistant_entries(entries):
    """Return ordered assistant text entries, each tagged with its governing prompt.

    Yields [{'uuid', 'text', 'gov'}] where 'gov' is the uuid of the most recent real
    user prompt preceding the assistant message. Sidechain (subagent) entries and
    non-text blocks (tool_use / tool_result) are excluded.

    Crucially, this captures EVERY assistant text entry individually rather than one
    blob per user prompt. That is what lets a later firing append text an earlier
    firing hadn't seen yet — the failure mode where a turn's final deliverable, emitted
    after a long stretch of tool calls, was silently lost.
    """
    out = []
    current_gov = None
    for entry in entries:
        if is_real_user_prompt(entry):
            current_gov = entry['uuid']
        elif entry.get('type') == 'assistant' and not entry.get('isSidechain', False):
            text = extract_text(entry.get('message', {}).get('content', []))
            if text and current_gov is not None:
                out.append({'uuid': entry['uuid'], 'text': text, 'gov': current_gov,
                            'ts': local_stamp(entry)})
    return out


def main():
    try:
        input_data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    if input_data.get('stop_hook_active'):
        sys.exit(0)

    transcript_path = input_data.get('transcript_path')
    if not transcript_path or not os.path.exists(transcript_path):
        sys.exit(0)

    # Anchor to the true project root via this script's own location
    # (<root>/.claude/hooks/append_raw.py → parents[2] == <root>), NOT the
    # transcript cwd. A session whose cwd is a subfolder would otherwise make the
    # hook create a stray 00_raw_capture/ there and split the capture stream.
    project_root = Path(__file__).resolve().parents[2]
    if not project_root.exists():
        sys.exit(0)

    # Concurrency guard — PostToolUse firings can overlap (parallel tool calls);
    # two instances reading the same state would double-append. If another
    # instance holds the lock, just exit: a later firing catches up via the
    # continuation mechanism, so skipped firings lose nothing.
    lock_path = project_root / '.claude' / 'hook_state.lock'
    try:
        if lock_path.exists() and time.time() - lock_path.stat().st_mtime > 30:
            lock_path.unlink()  # stale lock left by a killed instance
        fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
    except FileExistsError:
        sys.exit(0)
    except Exception:
        lock_path = None  # lock unavailable — capture anyway rather than skip

    try:
        run(input_data, transcript_path, project_root)
    finally:
        if lock_path is not None:
            try:
                lock_path.unlink()
            except Exception:
                pass


def run(input_data, transcript_path, project_root):
    user_label = get_user_label(project_root)

    # Load hook state — independent of session_state.json
    hook_state_file = project_root / '.claude' / 'hook_state.json'
    hook_state = {}
    if hook_state_file.exists():
        try:
            with open(hook_state_file) as f:
                hook_state = json.load(f)
        except Exception:
            pass

    last_asst_uuid = hook_state.get('last_written_assistant_uuid')
    prompt_map = hook_state.get('prompt_map', {})

    # Determine catch-all file — always the current month
    now = datetime.now()
    ym = now.strftime('%Y-%m')
    today = now.strftime('%Y-%m-%d')
    catchall_file = project_root / '00_raw_capture' / f'raw_({ym}).md'

    # Reset per-month counter and labels if the month has rolled over
    if hook_state.get('last_month') != ym:
        hook_state['exchange_count'] = 0
        prompt_map = {}

    exchange_count = hook_state.get('exchange_count', 0)

    # Read transcript — waiting briefly for the tail to flush. Stop fires only
    # after the turn's final assistant text exists, so a transcript whose last
    # conversational entry is NOT assistant text means that final write hasn't
    # landed on disk yet (the R217 race, 2026-07-09: hook read the file ~90ms
    # before the final message was flushed, capturing only a mid-turn note).
    # Retry briefly; if it never arrives, proceed — the continuation mechanism
    # picks the text up at the next firing, except at session end, which is
    # exactly the case this wait closes.
    def read_entries():
        out = []
        try:
            with open(transcript_path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            out.append(json.loads(line))
                        except Exception:
                            pass
        except Exception:
            return None
        return out

    def tail_has_final_text(entries):
        for entry in reversed(entries):
            if entry.get('isSidechain', False):
                continue
            if entry.get('type') == 'assistant':
                content = entry.get('message', {}).get('content', [])
                if isinstance(content, list) and any(
                    isinstance(b, dict) and b.get('type') == 'text' for b in content
                ):
                    return True
                return False  # tool_use tail — final text not flushed yet
            if entry.get('type') == 'user':
                return False  # tool_result (or prompt) tail — same
        return False

    entries = read_entries()
    if entries is None:
        sys.exit(0)
    for _ in range(6):
        if tail_has_final_text(entries):
            break
        time.sleep(0.3)
        reread = read_entries()
        if reread is not None:
            entries = reread

    # Map real user prompts to their text + capture time; collect ordered assistant text entries
    user_text = {}
    user_ts = {}
    for entry in entries:
        if is_real_user_prompt(entry):
            user_text[entry['uuid']] = extract_text(entry['message'].get('content', ''))
            user_ts[entry['uuid']] = local_stamp(entry)

    asst_entries = collect_assistant_entries(entries)
    if not asst_entries:
        sys.exit(0)

    # Resume after the last assistant entry already written. If that uuid isn't in
    # this transcript (None, or a different/compacted session), write everything.
    start = 0
    if last_asst_uuid is not None:
        for k, a in enumerate(asst_entries):
            if a['uuid'] == last_asst_uuid:
                start = k + 1
                break
    new_asst = asst_entries[start:]
    if not new_asst:
        sys.exit(0)

    # Group consecutive new assistant entries by the prompt that governs them
    groups = []
    for a in new_asst:
        if groups and groups[-1][0] == a['gov']:
            groups[-1][1].append(a['text'])
        else:
            groups.append([a['gov'], [a['text']], a['ts']])

    # Build content to append
    parts = []
    existing = catchall_file.read_text() if catchall_file.exists() else ''

    # File header on first write
    if not existing:
        parts.append(f'# Raw Capture — {user_label} — ({ym})\n\n')
        parts.append('Every session captured here verbatim, incrementally — the permanent record. ')
        parts.append('Distilled into the context files at each session close.\n')

    # Date header on first entry for today
    date_header = f'## {today}'
    if date_header not in existing and date_header not in ''.join(parts):
        parts.append(f'\n{date_header}\n')

    def label(base, stamp):
        return f'**{base}** *({stamp})*' if stamp else f'**{base}**'

    for gov, texts, ats in groups:
        combined = '\n\n'.join(texts)
        if gov in prompt_map:
            # An earlier firing already logged this prompt — append the later text
            # as a continuation rather than dropping it.
            n = prompt_map[gov]
            parts.append(f'\n{label(f"Claude-R{n} (cont.)", ats)}\n{combined}\n')
        else:
            exchange_count += 1
            prompt_map[gov] = exchange_count
            n = exchange_count
            parts.append(f'\n{label(f"{user_label}-P{n}", user_ts.get(gov, ""))}\n{user_text.get(gov, "")}\n')
            parts.append(f'\n{label(f"Claude-R{n}", ats)}\n{combined}\n')

    parts.append('\n---\n')

    # Write to catch-all — always
    try:
        catchall_file.parent.mkdir(parents=True, exist_ok=True)
        with open(catchall_file, 'a') as f:
            f.write(''.join(parts))
    except Exception:
        sys.exit(0)

    # Update hook state
    hook_state['last_written_assistant_uuid'] = new_asst[-1]['uuid']
    hook_state['prompt_map'] = prompt_map
    hook_state['exchange_count'] = exchange_count
    hook_state['last_month'] = ym
    hook_state.pop('last_written_uuid', None)  # retired key
    try:
        with open(hook_state_file, 'w') as f:
            json.dump(hook_state, f, indent=2)
    except Exception:
        pass

    sys.exit(0)


if __name__ == '__main__':
    main()
