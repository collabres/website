#!/usr/bin/env python3
"""
Modular Intelligence — raw conversation appender (Stop hook).

Client capture hook. Cross-platform (macOS/Windows). Set USER_LABEL below to the
client's first name at setup. Registered via .claude/settings.json (see setup_guide.md).

Fires after each Claude response. Always appends to the monthly catch-all file at
00_raw_capture/raw_(YYYY-MM).md regardless of session state. No dependency on
session_state.json — that file is for Claude's use only.

State is tracked in .claude/hook_state.json:
  last_written_uuid — avoids duplicate writes within the same conversation
  last_month        — detects month rollover so exchange count resets cleanly
  exchange_count    — sequential label counter for the current month's file
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path

# ── SET THIS at setup: the client's first name (labels their prompts in the log) ──
USER_LABEL = "User"


def extract_text(content):
    """Extract plain text from a message content field (string or list of blocks)."""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get('type') == 'text':
                text = block.get('text', '').strip()
                if text:
                    parts.append(text)
        return '\n\n'.join(parts)
    return ''


def is_real_user_prompt(entry):
    """Return True if this transcript entry is an actual user prompt."""
    if entry.get('type') != 'user':
        return False
    if entry.get('isSidechain', False):
        return False
    msg = entry.get('message', {})
    content = msg.get('content', '')
    if isinstance(content, list):
        if any(isinstance(b, dict) and b.get('type') == 'tool_result' for b in content):
            return False
        text = extract_text(content)
        if text.startswith('<') or not text:
            return False
        return True
    if isinstance(content, str):
        text = content.strip()
        if not text or text.startswith('<'):
            return False
        return True
    return False


def find_assistant_response(entries, user_entry_idx, next_user_entry_idx):
    """Collect all assistant text between this user prompt and the next, in order.

    Captures every text block Claude emits during the turn (concatenated) rather
    than only the final one — so reasoning narrated before tool calls is not
    silently dropped. Tool-use and tool-result blocks are still excluded, because
    extract_text() keeps only blocks of type 'text'.
    """
    texts = []
    end = next_user_entry_idx if next_user_entry_idx is not None else len(entries)
    for entry in entries[user_entry_idx + 1:end]:
        if entry.get('type') == 'assistant' and not entry.get('isSidechain', False):
            text = extract_text(entry.get('message', {}).get('content', []))
            if text:
                texts.append(text)
    return '\n\n'.join(texts)


def main():
    try:
        input_data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    if input_data.get('stop_hook_active'):
        sys.exit(0)

    transcript_path = input_data.get('transcript_path')
    if not transcript_path or not os.path.exists(transcript_path):
        sys.exit(0)

    # Anchor to the true project root via this script's own location
    # (<root>/.claude/hooks/append_raw.py → parents[2] == <root>), NOT the
    # transcript cwd. A session whose cwd is a subfolder would otherwise make the
    # hook create a stray 00_raw_capture/ there and split the capture stream.
    project_root = Path(__file__).resolve().parents[2]
    if not project_root.exists():
        sys.exit(0)

    # Load hook state — independent of session_state.json
    hook_state_file = project_root / '.claude' / 'hook_state.json'
    hook_state = {}
    if hook_state_file.exists():
        try:
            with open(hook_state_file) as f:
                hook_state = json.load(f)
        except Exception:
            pass

    last_uuid = hook_state.get('last_written_uuid')

    # Determine catch-all file — always the current month
    now = datetime.now()
    ym = now.strftime('%Y-%m')
    today = now.strftime('%Y-%m-%d')
    catchall_file = project_root / '00_raw_capture' / f'raw_({ym}).md'

    # Reset exchange count if the month has rolled over
    if hook_state.get('last_month') != ym:
        hook_state['exchange_count'] = 0

    exchange_count = hook_state.get('exchange_count', 0)

    # Read transcript
    try:
        entries = []
        with open(transcript_path) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except Exception:
                        pass
    except Exception:
        sys.exit(0)

    # Collect real user prompts in order
    user_prompts = []
    for i, entry in enumerate(entries):
        if is_real_user_prompt(entry):
            text = extract_text(entry['message'].get('content', ''))
            user_prompts.append({
                'uuid': entry['uuid'],
                'text': text,
                'entry_idx': i,
            })

    if not user_prompts:
        sys.exit(0)

    # Determine the write boundary.
    # If last_uuid is None: new hook state, write everything.
    # If last_uuid is found in this transcript: write only exchanges after it.
    # If last_uuid is NOT found in this transcript: this is a new conversation —
    #   write everything from the start (previous UUID belongs to a different session).
    uuid_in_transcript = any(up['uuid'] == last_uuid for up in user_prompts)
    found_boundary = (last_uuid is None) or (not uuid_in_transcript)

    new_exchanges = []
    for i, up in enumerate(user_prompts):
        if not found_boundary:
            if up['uuid'] == last_uuid:
                found_boundary = True
            continue

        next_idx = user_prompts[i + 1]['entry_idx'] if i + 1 < len(user_prompts) else None
        asst_text = find_assistant_response(entries, up['entry_idx'], next_idx)

        if asst_text:
            new_exchanges.append({
                'user_uuid': up['uuid'],
                'user': up['text'],
                'assistant': asst_text,
            })

    if not new_exchanges:
        sys.exit(0)

    # Build content to append
    parts = []
    existing = catchall_file.read_text() if catchall_file.exists() else ''

    # File header on first write
    if not existing:
        parts.append(f'# Raw Capture — {USER_LABEL} — ({ym})\n\n')
        parts.append('Every session captured here verbatim, incrementally — the permanent record. ')
        parts.append('Distilled into the context files at each session close.\n')

    # Date header on first entry for today
    date_header = f'## {today}'
    if date_header not in existing:
        parts.append(f'\n{date_header}\n')

    for ex in new_exchanges:
        exchange_count += 1
        parts.append(f'\n**{USER_LABEL}-P{exchange_count}**\n{ex["user"]}\n')
        parts.append(f'\n**Claude-R{exchange_count}**\n{ex["assistant"]}\n')

    parts.append('\n---\n')

    # Write to catch-all — always
    try:
        catchall_file.parent.mkdir(parents=True, exist_ok=True)
        with open(catchall_file, 'a') as f:
            f.write(''.join(parts))
    except Exception:
        sys.exit(0)

    # Update hook state
    hook_state['last_written_uuid'] = new_exchanges[-1]['user_uuid']
    hook_state['exchange_count'] = exchange_count
    hook_state['last_month'] = ym
    try:
        with open(hook_state_file, 'w') as f:
            json.dump(hook_state, f, indent=2)
    except Exception:
        pass

    sys.exit(0)


if __name__ == '__main__':
    main()
