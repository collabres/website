#!/usr/bin/env python3
"""
CR Engine — capture self-test (substrate).

The substrate spec made executable: verifies the capture system is correctly
installed and actually keeping the record. Run from anywhere inside the project:

    python3 .claude/selftest/capture_selftest.py        (macOS)
    python  .claude\\selftest\\capture_selftest.py       (Windows)

Checks (structural):
  1. settings.json exists, is valid JSON, and registers the capture hook on BOTH
     Stop and PostToolUse
  2. the hook file exists and compiles
  3. engine_config.json exists with a user_label and engine version stamps
  4. no stale concurrency lock is wedged
Checks (the record itself):
  5. 00_raw_capture/ exists and holds the current month's file (fresh installs
     pass with a note until the first exchange lands)
  6. the current month's file is growing — reports exchange count and the
     timestamp of the last write

Exit 0 = all checks pass. Exit 1 = at least one FAIL (details printed).
This script only READS. It never writes anything.
"""

import json
import os
import py_compile
import re
import sys
import time
from datetime import datetime
from pathlib import Path

# <root>/.claude/selftest/capture_selftest.py → parents[2] == <root>
PROJECT_ROOT = Path(__file__).resolve().parents[2]

results = []  # (status, name, detail)


def check(name, ok, detail, warn=False):
    status = 'PASS' if ok else ('NOTE' if warn else 'FAIL')
    results.append((status, name, detail))


def hook_registered(settings, event):
    for matcher in settings.get('hooks', {}).get(event, []):
        for h in matcher.get('hooks', []):
            blob = (h.get('command', '') or '') + ' ' + ' '.join(h.get('args', []) or [])
            if 'append_raw.py' in blob:
                return True
    return False


def main():
    # 1 — settings registration
    settings_file = PROJECT_ROOT / '.claude' / 'settings.json'
    settings = None
    if not settings_file.exists():
        # project-level installs sometimes use settings.local.json
        alt = PROJECT_ROOT / '.claude' / 'settings.local.json'
        settings_file = alt if alt.exists() else settings_file
    try:
        with open(settings_file) as f:
            settings = json.load(f)
        check('settings file', True, str(settings_file.name) + ' — valid JSON')
    except Exception as e:
        check('settings file', False, f'{settings_file} unreadable: {e}')

    if settings is not None:
        on_stop = hook_registered(settings, 'Stop')
        on_ptu = hook_registered(settings, 'PostToolUse')
        check('hook on Stop', on_stop, 'captures at end of every response' if on_stop
              else 'NOT registered — session-final text is not being captured')
        check('hook on PostToolUse', on_ptu, 'captures during the turn, before transcript pruning'
              if on_ptu else 'NOT registered — mid-turn text will be lost (pre-1.0 install?)')

    # 2 — hook file integrity
    hook_file = PROJECT_ROOT / '.claude' / 'hooks' / 'append_raw.py'
    if hook_file.exists():
        try:
            import tempfile
            with tempfile.TemporaryDirectory() as td:
                py_compile.compile(str(hook_file), doraise=True,
                                   cfile=os.path.join(td, 'selftest_check.pyc'))
            check('hook compiles', True, 'append_raw.py — syntax OK')
        except Exception as e:
            check('hook compiles', False, f'append_raw.py does not compile: {e}')
    else:
        check('hook file', False, f'missing: {hook_file}')

    # 3 — engine config
    cfg_file = PROJECT_ROOT / '.claude' / 'engine_config.json'
    try:
        with open(cfg_file) as f:
            cfg = json.load(f)
        label = cfg.get('user_label', '')
        ver = cfg.get('engine_version', '?')
        status = cfg.get('status', '?')
        check('engine config', bool(label),
              f'user_label={label or "MISSING"} · engine {ver} · status {status}')
    except Exception:
        check('engine config', False,
              'engine_config.json missing/unreadable — hook falls back to generic label',
              warn=True)

    # 4 — stale lock
    lock = PROJECT_ROOT / '.claude' / 'hook_state.lock'
    if lock.exists():
        age = time.time() - lock.stat().st_mtime
        check('concurrency lock', age < 30,
              f'lock present, {age:.0f}s old' + ('' if age < 30 else ' — stale; will self-clear on next firing'),
              warn=age >= 30)
    else:
        check('concurrency lock', True, 'clear')

    # 5/6 — the record
    ym = datetime.now().strftime('%Y-%m')
    raw_dir = PROJECT_ROOT / '00_raw_capture'
    month_file = raw_dir / f'raw_({ym}).md'
    if not raw_dir.exists():
        check('record folder', False, '00_raw_capture/ missing — no capture has ever run '
              '(fresh install: send one message and re-run)', warn=True)
    elif not month_file.exists():
        check('record folder', True, '00_raw_capture/ present')
        check('current month', False, f'{month_file.name} not yet created '
              '(no exchange this month yet — send one message and re-run)', warn=True)
    else:
        text = month_file.read_text()
        prompts = len(re.findall(r'^\*\*[^*\n]+-P\d+\*\*', text, re.M))
        mtime = datetime.fromtimestamp(month_file.stat().st_mtime)
        check('record folder', True, '00_raw_capture/ present')
        check('current month', True,
              f'{month_file.name}: {prompts} exchanges, last write {mtime:%Y-%m-%d %H:%M}')

    # Report
    print(f'CR Engine capture self-test — {PROJECT_ROOT.name} — '
          f'{datetime.now():%Y-%m-%d %H:%M}')
    print('-' * 72)
    failed = False
    for status, name, detail in results:
        print(f'  [{status:4}] {name:20} {detail}')
        if status == 'FAIL':
            failed = True
    print('-' * 72)
    print('RESULT: ' + ('FAIL — see above' if failed else 'PASS — the record is being kept'))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
